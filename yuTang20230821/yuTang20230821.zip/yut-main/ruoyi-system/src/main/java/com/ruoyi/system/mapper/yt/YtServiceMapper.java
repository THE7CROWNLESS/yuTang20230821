package com.ruoyi.system.mapper.yt;


import com.ruoyi.system.domain.yt.YtService;

import java.util.List;

public interface YtServiceMapper
{
    List<YtService> selectYtServiceList();
}

