package com.ruoyi.system.mapper.yt;


import com.ruoyi.system.domain.yt.vo.YtUserRechangeOrderVo;

import java.util.List;

public interface YtUserRechangeOrderMapper
{

    List<YtUserRechangeOrderVo> selectYtUserRechangeOrderList();

}
