package com.ruoyi.system.domain.to;

import lombok.Data;

/**
 * @author chenshijie
 * @date 2023/4/23 14:00
 */

@Data
public class LoginResonseBody {
    private long id;
    private String username;
}
