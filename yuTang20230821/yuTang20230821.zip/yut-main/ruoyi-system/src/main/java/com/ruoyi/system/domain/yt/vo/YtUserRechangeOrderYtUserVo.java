package com.ruoyi.system.domain.yt.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class YtUserRechangeOrderYtUserVo {

    private Integer id;
    private String username;
    private String openid;
    private String phone;





}
