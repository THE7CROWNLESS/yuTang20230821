package com.ruoyi.system.mapper.yt;

import java.util.List;
import com.ruoyi.system.domain.yt.YtFeeback;


public interface YtFeebackMapper 
{

    List<YtFeeback> selectYtFeebackList();

}
