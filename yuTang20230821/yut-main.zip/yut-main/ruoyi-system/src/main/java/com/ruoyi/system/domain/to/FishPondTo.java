package com.ruoyi.system.domain.to;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FishPondTo {
    private String fishPond;
    private String machineCode;

}
